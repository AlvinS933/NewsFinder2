import { useState } from "react";

const Simulator = () => {
    const [title, setTitle] = useState("");
    const [source, setSource] = useState("");
    const [articleText, setArticleText] = useState("");
    const [url, setUrl] = useState("");
    const [date, setDate] = useState("");
    const handleClear = () => {
        setTitle("");
        setSource("");
        setArticleText("");
        setUrl("");
        setDate("");
    }
    return (
        <div>
            <div className="simulatorInputs">
                <h2 style={{visibility: "hidden"}}>Simulator Component</h2>
                <form>
                    <label>Title:</label>
                    <input type="text" value ={title} onChange = {(e) => setTitle(e.target.value)}/>
                    <label>Source:</label>
                    <input type="text" value ={source} onChange = {(e) => setSource(e.target.value)}/>
                    <label>Article Text:</label>
                    <textarea value ={articleText} onChange = {(e) => setArticleText(e.target.value)}/>
                    <label>URL:</label>
                    <input type="text" value ={url} onChange = {(e) => setUrl(e.target.value)} />
                    <label>Date:</label>
                    <input type="date" value ={date} onChange = {(e) => setDate(e.target.value)} />
                </form>
                <div className ="button-group">
                    <button className = "clear-button" type = "button" onClick={handleClear}>CLEAR</button>
                    <button>SUBMIT</button>
                </div>
            </div>
            <div className="simulatorOutputs">
                <h2 style={{visibility: "hidden"}}>Simulator Result</h2>
                <form>
                    <label>Simulated Transcript:</label>
                    <textarea readOnly defaultValue="..." />
                    <label>Simulated Actions:</label>
                    <textarea readOnly defaultValue="..." />
                    <label>Shared Facts:</label>
                    <textarea readOnly defaultValue="..." />
                    <label>Raw Json:</label>
                    <textarea readOnly defaultValue="..." />
                </form>
            </div>
        </div>
    );
};

export default Simulator;
